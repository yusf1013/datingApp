CREATE VIEW view_name as
	select * from my_table;

